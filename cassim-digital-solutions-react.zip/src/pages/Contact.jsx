import React from "react";

export default function Contact() {
  return (
    <div className="p-4">
      <h2 className="text-2xl font-semibold mb-4">Contact Us</h2>
      <p>Email: andrecassim@hotmail.com</p>
      <p>Phone: 073 503 64425</p>
      <p>Location: Centurion, South Africa</p>
    </div>
  );
}
