import React from "react";

export default function Services() {
  return (
    <div className="p-4">
      <h2 className="text-2xl font-semibold mb-4">Our Services</h2>
      <ul className="list-disc list-inside">
        <li>Web & Mobile Development</li>
        <li>SEO & Digital Marketing</li>
        <li>Infrastructure & IT Support</li>
        <li>BI & Analytics</li>
        <li>UI/UX & Graphic Design</li>
      </ul>
    </div>
  );
}
