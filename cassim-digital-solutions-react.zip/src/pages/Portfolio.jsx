import React from "react";

export default function Portfolio() {
  return (
    <div className="p-4">
      <h2 className="text-2xl font-semibold mb-4">Portfolio Highlights</h2>
      <ul className="list-disc list-inside">
        <li>www.electric247.co.za</li>
        <li>www.nscstationers.co.za</li>
        <li>www.citizen.co.za</li>
        <li>www.womanandhome.co.za</li>
        <li>www.yourfamily.co.za</li>
      </ul>
    </div>
  );
}
